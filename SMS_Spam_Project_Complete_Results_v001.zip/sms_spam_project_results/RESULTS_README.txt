SMS SPAM DETECTION - AI SEMESTER PROJECT

PROJECT CONFIGURATION
{
  "project": "SMS Spam Detection - AI Course Project",
  "model": "google/flan-t5-base",
  "seed": 42,
  "python": "3.13.16",
  "pytorch": "2.14.1+cu130",
  "training_count": 3870,
  "development_count": 240,
  "e05_holdout_count": 300,
  "e05_candidate_pool_size": 1050,
  "development_changed_count": 48,
  "e05_changed_count": 38,
  "e04_note": "12 synthetic topic-labeled messages; qualitative analysis only",
  "evaluation_note": "E05 is separate from training and development",
  "runtime_note": "Obfuscated inference time measures incremental changed-message processing",
  "classification_methods": [
    "Word TF-IDF + LR",
    "E02 Zero-shot",
    "E02 Few-shot",
    "E03 FLAN-T5 Label Scoring",
    "E03 Character TF-IDF + LR"
  ]
}

DEVELOPMENT RESULTS
experiment                    method   scenario   n  changed_in_full_set  accuracy  spam_precision  spam_recall  spam_f1  invalid_outputs  inference_seconds
       E01          Word TF-IDF + LR   Original 240                   48    0.9792          0.9310       0.9000   0.9153                0              0.013
       E01          Word TF-IDF + LR Obfuscated 240                   48    0.9750          0.9286       0.8667   0.8966                0              0.005
       E01             E01 Zero-shot   Original 240                   48    0.1500          0.1282       1.0000   0.2273                0              9.572
       E01             E01 Zero-shot Obfuscated 240                   48    0.1500          0.1282       1.0000   0.2273                0              0.727
       E01              E01 Few-shot   Original 240                   48    0.1625          0.1299       1.0000   0.2299                0              6.492
       E01              E01 Few-shot Obfuscated 240                   48    0.1625          0.1299       1.0000   0.2299                0              1.313
       E02             E02 Zero-shot   Original 240                   48    0.8208          0.3774       0.6667   0.4819                0              4.137
       E02             E02 Zero-shot Obfuscated 240                   48    0.8083          0.3400       0.5667   0.4250                0              0.852
       E02              E02 Few-shot   Original 240                   48    0.4667          0.1899       1.0000   0.3191                0              6.876
       E02              E02 Few-shot Obfuscated 240                   48    0.4625          0.1887       1.0000   0.3175                0              1.526
       E03 E03 FLAN-T5 Label Scoring   Original 240                   48    0.9417          0.8636       0.6333   0.7308                0              4.709
       E03 E03 FLAN-T5 Label Scoring Obfuscated 240                   48    0.9333          0.8500       0.5667   0.6800                0              1.051
       E03 E03 Character TF-IDF + LR   Original 240                   48    0.9875          1.0000       0.9000   0.9474                0              0.082
       E03 E03 Character TF-IDF + LR Obfuscated 240                   48    0.9875          1.0000       0.9000   0.9474                0              0.021

E05 FINAL HOLDOUT RESULTS
experiment                    method   scenario   n  changed_in_full_set  accuracy  spam_precision  spam_recall  spam_f1  invalid_outputs  inference_seconds
       E05          Word TF-IDF + LR   Original 300                   38    0.9800          0.8780       0.9730   0.9231                0              0.026
       E05          Word TF-IDF + LR Obfuscated 300                   38    0.9867          0.9459       0.9459   0.9459                0              0.008
       E05             E02 Zero-shot   Original 300                   38    0.8833          0.5179       0.7838   0.6237                0              4.773
       E05             E02 Zero-shot Obfuscated 300                   38    0.8667          0.4717       0.6757   0.5556                0              0.710
       E05              E02 Few-shot   Original 300                   38    0.5400          0.2114       1.0000   0.3491                0              5.156
       E05              E02 Few-shot Obfuscated 300                   38    0.5367          0.2102       1.0000   0.3474                0              0.774
       E05 E03 FLAN-T5 Label Scoring   Original 300                   38    0.9533          0.9259       0.6757   0.7812                0              5.380
       E05 E03 FLAN-T5 Label Scoring Obfuscated 300                   38    0.9400          0.9130       0.5676   0.7000                0              0.873
       E05 E03 Character TF-IDF + LR   Original 300                   38    0.9833          0.9211       0.9459   0.9333                0              0.082
       E05 E03 Character TF-IDF + LR Obfuscated 300                   38    0.9833          0.9706       0.8919   0.9296                0              0.016

IMPORTANT NOTES
E04 contains synthetic messages without binary spam ground truth.
E05 should not be used for further prompt tuning.
Historical results are separate from newly generated measurements.